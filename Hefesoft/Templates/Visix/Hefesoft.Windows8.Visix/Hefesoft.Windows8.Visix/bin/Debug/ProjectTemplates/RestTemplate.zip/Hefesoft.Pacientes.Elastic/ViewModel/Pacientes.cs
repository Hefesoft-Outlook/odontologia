﻿using GalaSoft.MvvmLight;
using GalaSoft.MvvmLight.Command;
using Hefesoft.Standard.BusyBox;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Hefesoft.Standard.Util.Collection.Observables;
using Hefesoft.Standard.Util.Collection.IEnumerable;
using System.Collections.ObjectModel;

namespace $safeprojectname$.ViewModel
{
    public class $nombreProyectoSinHefesoft$ : ViewModelBase
    {
        public $nombreProyectoSinHefesoft$()
        {
            Listado = new ObservableCollection<$safeprojectname$.Entidades.$nombreProyectoSinHefesoft$>();
            if (IsInDesignMode)
            {
                datosDisenio();
            }
            else
            {
                data = new Data.Crud();
                listar();                
                insertCommand = new RelayCommand(insert);
            }
        }

        private void datosDisenio()
        {
            Listado.Add(new $safeprojectname$.Entidades.$nombreProyectoSinHefesoft$()
            {
                Codigo = 1,
                Descripcion = "Test"
            });
        }

        private async void listar()
        {
            var query = new $safeprojectname$.Entidades.$nombreProyectoSinHefesoft$()
            {
                nombreTabla = "PruebaElastic"
            };

            var result = await data.getAllTableStorage(query);
            Listado = result.ToObservableCollection();
            RaisePropertyChanged("Listado");
        }

        private async void insert()
        {
            //Este es el identificador en table storage
            Seleccionado.RowKey = new Random().Next().ToString();
            await data.insert(Seleccionado);
            Listado.Add(Seleccionado);
            RaisePropertyChanged("Listado");
        }


        private Data.Crud data;
        private $safeprojectname$.Entidades.$nombreProyectoSinHefesoft$ seleccionado = new Entidades.$nombreProyectoSinHefesoft$() { nombreTabla = "PruebaElastic" };

        public $safeprojectname$.Entidades.$nombreProyectoSinHefesoft$ Seleccionado
        {
            get { return seleccionado; }
            set { seleccionado = value; RaisePropertyChanged("Seleccionado"); }
        }


        public RelayCommand insertCommand { get; set; }

        public ObservableCollection<$safeprojectname$.Entidades.$nombreProyectoSinHefesoft$> Listado { get; set; }
    }
}
