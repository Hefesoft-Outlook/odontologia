﻿using GalaSoft.MvvmLight;
using GalaSoft.MvvmLight.Command;
using Hefesoft.Standard.BusyBox;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace $safeprojectname$.ViewModel
{
    public class Pacientes : ViewModelBase
    {
        public Pacientes()
        {
            if(IsInDesignMode)
            {

            }
            else
            {
                data = new Data.Crud();
                insertCommand = new RelayCommand(insert);
                
            }
        }

        private async void insert()
        {            
            await data.insert(Seleccionado);         
        }
        

        private Data.Crud data;
        private $safeprojectname$.Entidades.Paciente seleccionado = new Entidades.Paciente() { nombreTabla = "PruebaElastic" };
        
        public $safeprojectname$.Entidades.Paciente Seleccionado
        {
            get { return seleccionado; }
            set { seleccionado = value; RaisePropertyChanged("Seleccionado"); }
        }


        public RelayCommand insertCommand { get; set; }
    }
}
