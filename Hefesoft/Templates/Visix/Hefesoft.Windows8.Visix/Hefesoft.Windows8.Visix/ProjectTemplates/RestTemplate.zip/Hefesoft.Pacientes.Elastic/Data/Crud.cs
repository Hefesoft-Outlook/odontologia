﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Hefesoft.Standard.Util.table;
using Hefesoft.Standard.Util.Blob;

namespace $safeprojectname$.Data
{
    internal class Crud
    {

        internal async Task<bool> insert($safeprojectname$.Entidades.Paciente entidad)
        {
            await entidad.postBlob();
            await entidad.postTable();
            return true;
        }

    }
}
