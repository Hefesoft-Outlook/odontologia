﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Contracts;

namespace $safeprojectname$
{
    [ExportWidget(name = "$safeprojectname$", Location = WidgetLocation.UserControl, XapName = "$safeprojectname$.xap", Version = "1.0", InitialPage = false)]
    public partial class MainPage : UserControl
    {
        #region Host
        ///Descomentarear para usar elementos del host
        //The_Windmill_Project.Controls.BusyIndicator busy = ((The_Windmill_Project.Controls.BusyIndicator)(App.Current.RootVisual));

        //The_Windmill_Project.ViewModel.MainViewModel mainViewModel; 
        #endregion

        public MainPage()
        {
            InitializeComponent();
            this.DataContext = new ViewModel.MainPageViewModel();
            Loaded += new RoutedEventHandler(MainPage_Loaded);

            if (Application.Current is The_Windmill_Project.App)
            {
                The_Windmill_Project.MainPage mainContenedor = ((The_Windmill_Project.MainPage)(((System.Windows.Controls.ContentControl)(((The_Windmill_Project.Controls.BusyIndicator)(App.Current.RootVisual)))).Content));
                mainContenedor.ShowLoadingSplash("$safeprojectname$", "#FF66A2F3");
                mainContenedor.ShowLoadingSplashEvent += (m, n) =>
                {
                    mainContenedor.CollapsedLoadingSplash();
                };
            }
        }

        void MainPage_Loaded(object sender, RoutedEventArgs e)
        {

        }

        private void HyperlinkButton_Click(object sender, System.Windows.RoutedEventArgs e)
        {
            string opcion = ((HyperlinkButton)sender).Content.ToString();

            if (opcion == "Cuentas")
            {
               
            }
            else if (opcion == "Conceptos")
            {
               
            }
            else if (opcion == "Centros de costo")
            {
               
            }
        }
    }
}
